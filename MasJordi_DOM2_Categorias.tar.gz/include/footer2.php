<div class="container" id='footer'>
<!-- Footer -->
<footer>
<div class="row">
    <div class="col-lg-12">
        <p>Copyright &copy; Plantas El Caminàs 2018</p>
    </div>
</div>
</footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src="/tienda/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="/tienda/js/bootstrap.min.js"></script>
</body>

</html>
